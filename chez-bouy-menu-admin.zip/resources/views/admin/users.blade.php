@extends('admin.layout')

@section('title', __('admin.users'))

@section('admin-content')
    <h2>{{ __('admin.users') }}</h2>
@endsection
